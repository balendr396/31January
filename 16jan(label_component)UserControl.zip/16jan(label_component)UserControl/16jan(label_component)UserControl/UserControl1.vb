﻿Imports System.ComponentModel
Imports System.Data.SqlClient
'Imports _19jan_sharablearray_classcomponent



Public Class UserControl1
    ' Dim vbr As New Class1
    Dim m As Int16
    Dim n As Integer
    Public Shared arr As Int16()


    Public Shared str As String
    ' Private ReadOnly Class1 As Object


    <Browsable(True),
Category("_MISC"), System.ComponentModel.Description("Enter Starting Num")>
    Public Property startingnum() As Int16
        Get
            Return m
        End Get
        Set(value As Int16)
            m = value
        End Set
    End Property


    <Browsable(True),
Category("_MISC"), System.ComponentModel.Description("Enter num for Consecutive numbers
")>
    Public Property consecutivenum() As Integer
        Get
            Return n
        End Get
        Set(value As Integer)
            n = value
        End Set
    End Property



    'This function returns a string starting from m in the int16array to next n consecutive numbers 
    Public Function result(ar() As Short) As String


        str = ""
        MyBase.Text = ""
        Dim i As Integer
        arr = ar

        Dim newArray() As Short = arr.ToArray()

        Dim startidx As Integer = Array.IndexOf(newArray, m)


        For i = startidx To startidx + n - 1
            If str = "" Then
                str = str + "" + newArray(i).ToString
            Else
                str = str + "," + newArray(i).ToString

            End If



        Next i

        ' Debug.Write(str)
        Label1.Text = str
        Return str



    End Function



End Class
