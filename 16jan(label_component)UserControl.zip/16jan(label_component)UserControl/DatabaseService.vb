﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient

Public Class Class1

End Class
