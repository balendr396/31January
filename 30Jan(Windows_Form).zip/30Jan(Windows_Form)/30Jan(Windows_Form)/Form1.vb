﻿Imports _19jan_sharablearray_classcomponent

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick


        UserControl11.result(Class1.SetShareablearray)
    End Sub
End Class
