﻿
Imports System.Windows.Controls
Imports System.Windows.Forms

Public Class Class1
    Inherits Windows.Forms.UserControl



    Public Shared array12() As Int16


    Private WithEvents timer1 As New Timer()

    Public Sub New()
        ' This is the form's constructor
        '   InitializeComponent()

        ' Set the interval to 1000 milliseconds (1 second)
        timer1.Interval = 1000
        ' Start the timer
        timer1.Start()
    End Sub

    'Private Sub InitializeComponent()
    '    Throw New NotImplementedException()
    'End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles timer1.Tick
        ' This code will be executed every time the timer ticks

        SetShareablearray()

    End Sub


    ' Add any additional controls or properties as needed

    ' Shared method to set the shareable string for the user control
    Public Shared Function SetShareablearray() As Int16()
        Dim vbr As New DatabaseHandler

        Dim int16Array As Int16() = vbr.RetrieveValuesAsArray()

        array12 = int16Array.ToArray
        Return array12

    End Function






End Class
